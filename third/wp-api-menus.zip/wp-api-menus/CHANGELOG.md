### 1.1.4 (30 apr 2015)
Supports WordPress 4.2, add composer.json for wp-packagist

### 1.1.3 (13 Mar 2015)
* Fixes bug where duplicate items where created in nested menus - props @josh-taylor

### 1.1.2 (10 Feb 2015)
* Introduced `json_menus_format_menu_item` filter hook - props @Noctine

### 1.1.1 (15 Jan 2015)
* Submission to WordPress.org plugins repository.

### 1.1.0 (24 Nov 2014)
* Fixed typo confusing `parent` with `collection` in meta
* Routes for menus in theme locations now include complete tree with item order and nested children 
* `description` attribute for individual items is now included in results

### 1.0.0 (21 Jul 2014)
First public release